<?php

namespace App\Http\Controllers;

use App\Models\Usuario;
use Illuminate\Http\Request;

class usuarioController extends Controller
{
    //

    public function index()
    {
        return Usuario::all();

    }

    public function show($id){
        return Usuario::find($id);
   }

    public function store(Request $request)
    {
        $usuario = Usuario::create($request->all());

       // return $categoria;
        return response()->json($usuario, 201);
    }

    public function edit(Request $request, $id){
        
        $nombre=$request->input('nombre');
        $telefono=$request->input('telefono');
        $estado=$request->input('estado');

        Usuario::where('id_usuario',$id)->update(
            ['nombre'=>$nombre,'telefono'=>$telefono,'estado'=>$estado]
            );
            return json_encode(['msg'=>'Modificado y Actualizado']);
    }





  
}
